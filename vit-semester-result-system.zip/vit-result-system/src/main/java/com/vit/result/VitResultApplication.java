package com.vit.result;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class VitResultApplication { public static void main(String[] args) { SpringApplication.run(VitResultApplication.class,args); } }
